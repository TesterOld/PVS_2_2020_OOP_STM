#include "stm32f10x.h"
#include "Configuration.h"
#include "TaskManager.h"

GPIO ledRedGPIO(GPIOB,0,GPIO_Mode_Out_PP,GPIO_Speed_50MHz);//LED GPIO
GPIO ledBlueGPIO(GPIOB,1,GPIO_Mode_Out_PP,GPIO_Speed_50MHz);//LED GPIO

int main()
{
	
	double record_tmgTest=0; //taskmanager时间 测试
	while(1)
	{
		if(tskmgr.TimeSlice(record_tmgTest,0.2)) //每0.2秒执行一次
		{
			
//			ledBlue.Toggle();
		}
		
	}
}
