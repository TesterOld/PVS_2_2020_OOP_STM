#ifndef __ASSERT_H
#define __ASSERT_H

#ifdef __cplusplus
extern "C"
{
#endif

#include "stm32f10x_conf.h"

#define assert(pass) assert_param(pass)


#ifdef __cplusplus
}
#endif

#endif

