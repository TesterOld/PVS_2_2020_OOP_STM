#include "UserInterrupt.h"


/*************************TIM_USER_IRQ***********************************/
//#ifdef USE_TIMER1
//void Timer1_IRQ()
//{
//	
//}
//#endif

//#ifdef USE_TIMER2
//void Timer2_IRQ()
//{
//	
//}
//#endif

//#ifdef USE_TIMER3
//void Timer3_IRQ()
//{
//	
//}
//#endif

//#ifdef USE_TIMER4
//void Timer4_IRQ()
//{
//	
//}
//#endif


/*************************EXIT_USER_IRQ***************************************/
//#ifdef USE_EXTI0
//void	EXTI0_IRQ()
//{
//}
//#endif
//#ifdef USE_EXTI1
//void	EXTI1_IRQ()
//{
//}
//#endif
//#ifdef USE_EXTI2
//void	EXTI2_IRQ()
//{
//}
//#endif
//#ifdef USE_EXTI3
//void	EXTI3_IRQ()
//{
//}
//#endif
//#ifdef USE_EXTI4
//void	EXTI4_IRQ()
//{
//}
//#endif
//#ifdef USE_EXTI5
//void	EXTI5_IRQ()
//{
//}
//#endif
//#ifdef USE_EXTI6
//void	EXTI6_IRQ()
//{
//}
//#endif
//#ifdef USE_EXTI7
//void	EXTI7_IRQ()
//{
//}
//#endif
//#ifdef USE_EXTI8
//void	EXTI8_IRQ()
//{
//}
//#endif
//#ifdef USE_EXTI9
//void	EXTI9_IRQ()
//{
//}
//#endif
//#ifdef USE_EXTI10
//void	EXTI10_IRQ()
//{
//}
//#endif
//#ifdef USE_EXTI11
//void	EXTI11_IRQ()
//{
//}
//#endif
//#ifdef USE_EXTI12
//void	EXTI12_IRQ()
//{
//}
//#endif
//#ifdef USE_EXTI13
//void	EXTI13_IRQ()
//{
//}
//#endif
//#ifdef USE_EXTI14
//void	EXTI14_IRQ()
//{
//}
//#endif
//#ifdef USE_EXTI15
//void	EXTI15_IRQ()
//{
//}
//#endif
